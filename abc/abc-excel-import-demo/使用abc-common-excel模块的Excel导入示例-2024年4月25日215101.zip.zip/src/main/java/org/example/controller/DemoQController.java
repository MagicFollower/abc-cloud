package org.example.controller;

import com.abc.system.common.response.ResponseData;
import com.abc.system.excel.service.ExcelFileService;
import com.abc.system.excel.vo.ExcelResponse;
import com.alibaba.fastjson2.JSONObject;
import com.alibaba.fastjson2.JSONWriter;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Collection;

@RestController
@RequestMapping("/demoQ")
@RequiredArgsConstructor
public class DemoQController {

    private final ExcelFileService excelFileService;

    @PostMapping("/parseExcel")
    public void parseExcel(HttpServletRequest httpServletRequest) {
        ResponseData<ExcelResponse> excelResponseResponseData = excelFileService.dealWith(httpServletRequest);
        ExcelResponse result = excelResponseResponseData.getResult();
        Collection<String> displayTitle = result.getDisplayTitle();
        Collection<String> displayData = result.getDisplayData();
        Collection<JSONObject> realData = result.getRealData();

        System.out.println("displayTitle = \n" + displayTitle);
        System.out.println("displayData = \n" + displayData);

        realData.forEach(x -> {
            System.out.println(x.toJSONString(JSONWriter.Feature.PrettyFormat));
        });
    }
}
